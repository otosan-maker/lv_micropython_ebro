import machine

machine.reset()
